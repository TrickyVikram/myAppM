package onvtech.OnVTech;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnVTechApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnVTechApplication.class, args);
	}

}
